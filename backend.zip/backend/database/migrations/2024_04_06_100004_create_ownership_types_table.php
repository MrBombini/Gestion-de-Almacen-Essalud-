<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ownership_types', function (Blueprint $table) {
            $table->id();
            $table->string('name', 50)->unique(); // EsSalud, Proveedor
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ownership_types');
    }
};
